const $=id=>document.getElementById(id);
const surahSelect=$('surah'), juzSelect=$('juz'), statusBox=$('status'), versesBox=$('verses'), player=$('player');
const STORE='hafalanForumDawai_v4', CACHE='hafalanForumDawai_cache_v1';
let currentSurah=null, hideText=false, currentAudioUrl=null, loopLeft=0, loopStart=0, loopEnd=0, loopTimer=null, activeVerseIndex=0, currentSource='', playToken=0, isPlayingSequence=false;
const juzRanges={
1:[1,2],2:[2,2],3:[2,3],4:[3,4],5:[4,4],6:[4,5],7:[5,6],8:[6,7],9:[7,8],10:[8,9],11:[9,11],12:[11,12],13:[12,14],14:[15,16],15:[17,18],16:[18,20],17:[21,22],18:[23,25],19:[25,27],20:[27,29],21:[29,33],22:[33,36],23:[36,39],24:[39,41],25:[41,45],26:[46,51],27:[51,57],28:[58,66],29:[67,77],30:[78,114]}
;
const juzAyahBounds={
1:[[1,1],[2,141]],2:[[2,142],[2,252]],3:[[2,253],[3,92]],4:[[3,93],[4,23]],5:[[4,24],[4,147]],6:[[4,148],[5,81]],7:[[5,82],[6,110]],8:[[6,111],[7,87]],9:[[7,88],[8,40]],10:[[8,41],[9,92]],11:[[9,93],[11,5]],12:[[11,6],[12,52]],13:[[12,53],[14,52]],14:[[15,1],[16,128]],15:[[17,1],[18,74]],16:[[18,75],[20,135]],17:[[21,1],[22,78]],18:[[23,1],[25,20]],19:[[25,21],[27,55]],20:[[27,56],[29,45]],21:[[29,46],[33,30]],22:[[33,31],[36,27]],23:[[36,28],[39,31]],24:[[39,32],[41,46]],25:[[41,47],[45,37]],26:[[46,1],[51,30]],27:[[51,31],[57,29]],28:[[58,1],[66,12]],29:[[67,1],[77,50]],30:[[78,1],[114,6]]}
;
const surahNames={
1:'Al-Fatihah',2:'Al-Baqarah',3:'Ali Imran',4:'An-Nisa',5:'Al-Maidah',6:'Al-Anam',7:'Al-Araf',8:'Al-Anfal',9:'At-Taubah',10:'Yunus',11:'Hud',12:'Yusuf',13:'Ar-Rad',14:'Ibrahim',15:'Al-Hijr',16:'An-Nahl',17:'Al-Isra',18:'Al-Kahfi',19:'Maryam',20:'Taha',21:'Al-Anbiya',22:'Al-Hajj',23:'Al-Muminun',24:'An-Nur',25:'Al-Furqan',26:'Asy-Syuara',27:'An-Naml',28:'Al-Qasas',29:'Al-Ankabut',30:'Ar-Rum',31:'Luqman',32:'As-Sajdah',33:'Al-Ahzab',34:'Saba',35:'Fatir',36:'Yasin',37:'As-Saffat',38:'Sad',39:'Az-Zumar',40:'Ghafir',41:'Fussilat',42:'Asy-Syura',43:'Az-Zukhruf',44:'Ad-Dukhan',45:'Al-Jasiyah',46:'Al-Ahqaf',47:'Muhammad',48:'Al-Fath',49:'Al-Hujurat',50:'Qaf',51:'Az-Zariyat',52:'At-Tur',53:'An-Najm',54:'Al-Qamar',55:'Ar-Rahman',56:'Al-Waqiah',57:'Al-Hadid',58:'Al-Mujadilah',59:'Al-Hasyr',60:'Al-Mumtahanah',61:'As-Saff',62:'Al-Jumuah',63:'Al-Munafiqun',64:'At-Taghabun',65:'At-Talaq',66:'At-Tahrim',67:'Al-Mulk',68:'Al-Qalam',69:'Al-Haqqah',70:"Al-Ma'arij",71:'Nuh',72:'Al-Jinn',73:'Al-Muzzammil',74:'Al-Muddaththir',75:'Al-Qiyamah',76:'Al-Insan',77:'Al-Mursalat',78:"An-Naba'",79:"An-Nazi'at",80:'Abasa',81:'At-Takwir',82:'Al-Infitar',83:'Al-Mutaffifin',84:'Al-Insyiqaq',85:'Al-Buruj',86:'At-Tariq',87:'Al-Ala',88:'Al-Ghasyiyah',89:'Al-Fajr',90:'Al-Balad',91:'Asy-Syams',92:'Al-Lail',93:'Ad-Duha',94:'Asy-Syarh',95:'At-Tin',96:'Al-Alaq',97:'Al-Qadr',98:'Al-Bayyinah',99:'Az-Zalzalah',100:'Al-Adiyat',101:'Al-Qariah',102:'At-Takatsur',103:'Al-Asr',104:'Al-Humazah',105:'Al-Fil',106:'Quraisy',107:'Al-Maun',108:'Al-Kausar',109:'Al-Kafirun',110:'An-Nasr',111:'Al-Lahab',112:'Al-Ikhlas',113:'Al-Falaq',114:'An-Nas'}
;
const ayahCounts=[7,286,200,176,120,165,206,75,129,109,123,111,43,52,99,128,111,110,98,135,112,78,118,64,77,227,93,88,69,60,34,30,73,54,45,83,182,88,75,85,54,53,89,59,37,35,38,29,18,45,60,49,62,55,78,96,29,22,24,13,14,11,11,18,12,12,30,52,52,44,28,28,20,56,40,31,50,40,46,42,29,19,36,25,22,17,19,26,30,20,15,21,11,8,8,19,5,8,8,11,11,8,3,9,5,4,7,3,6,3,5,4,5,6];
const quranCache={
}
;
function readStore(){
try{
return JSON.parse(localStorage.getItem(STORE)||'{
}
')}
catch{
return {
}
}
}
function writeStore(v){
try{
localStorage.setItem(STORE,JSON.stringify(v))}
catch(e){
statusBox.textContent='Penyimpanan browser penuh/tidak tersedia.'}
}
function key(s,a){
return `${
s}
:${
a}
`}
function clean(x){
if(x==null)return '';
if(typeof x==='string')return x.replace(/<[^>]*>/g,'').replace(/&nbsp;
/g,' ').trim();
if(typeof x==='object'){
if(x.text)return clean(x.text);
if(x.id)return clean(x.id);
if(x.en)return clean(x.en);
return ''}
return String(x)}
async function fetchJSON(url){
const r=await fetch(url,{
headers:{
'Accept':'application/json'}
}
);
if(!r.ok)throw new Error(`${
r.status}
${
r.statusText}
`);
return r.json()}
function unwrap(j){
return j?.data?.data||j?.data||j?.result||j}
function getNum(v,i){
return v?.__inSurah??v?.number?.inSurah??v?.numberInSurah??v?.ayah_number??(typeof v?.number==='number'&&v.number<=286?v.number:null)??i+1}
function normalizeSurahData(n,obj){
if(!obj||!Array.isArray(obj.verses))return null;
const expected=ayahCounts[n-1];
if(obj.verses.length!==expected)return null;
obj.verses=obj.verses.map((v,i)=>({
...v,__inSurah:i+1}
));
return obj}
function completeSurahData(n,obj){
return !!obj&&Array.isArray(obj.verses)&&obj.verses.length===ayahCounts[n-1]}
function arabOf(v){
return clean(v?.arab||v?.text?.arab||v?.text_uthmani||v?.arabic||v?.text?.uthmani||v?.text)||'Teks Arab tidak tersedia'}
function latinOf(v){
let t=v?.transliteration;
if(typeof t==='object') t=t.id||t.en||t.text;
t=t||v?.text?.transliteration?.id||v?.text?.transliteration?.en||v?.latin||v?.latin_text||v?.transliteration_id;
return clean(t)||'Transliterasi belum tersedia dari sumber ini'}
function transOf(v){
return clean(v?.translation?.id||v?.translation?.text||v?.translation||v?.translations?.id||v?.arti||v?.text?.translation?.id||v?.text?.translation)||'Terjemahan belum tersedia dari sumber ini'}
function tafsirText(x){
if(x==null)return '';
if(typeof x==='string'||typeof x==='number')return clean(x);
if(typeof x==='object')return clean(x.text||x.value||x.content||x.tafsir||x.id||x.indonesia||x.short||x.long||x.tahlili||x.ringkas);
return ''}
function tafsirOf(v,mode){
const t=v?.tafsir||v?.tafsirs||v?.interpretation||{
}
;
const k=t?.kemenag||t?.kemendagri||v?.tafsir_kemenag||v?.tafsirKemenag||{
}
;
if(mode==='kemenagShort')return tafsirText(k?.short||k?.ringkas||k?.tafsir_ringkas||v?.tafsir_kemenag_ringkas||v?.tafsir_ringkas);
if(mode==='kemenagLong')return tafsirText(k?.long||k?.tahlili||k?.tafsir_tahlili||v?.tafsir_kemenag_tahlili||v?.tafsir_tahlili);
if(mode==='quraish')return tafsirText(t?.quraish||t?.quraisy||t?.quraish_shihab||t?.quraishShihab||v?.tafsir_quraish||v?.tafsir_quraish_shihab||v?.tafsirQuraishShihab);
if(mode==='jalalayn')return tafsirText(t?.jalalayn||t?.jalalain||v?.tafsir_jalalayn||v?.tafsir_jalalain);
return ''}
async function enrichWithTafsir(n,result){
if(!result||!Array.isArray(result.verses))return result;
try{
let d=null,arr=[];
for(const url of [`https://quran-api-id.vercel.app/surahs/${
n}
`,`https://quran-api-id.vercel.app/surahs/${
n}
/ayahs`]){
try{
const raw=await fetchJSON(url);
d=unwrap(raw);
arr=Array.isArray(d)?d:(d?.verses||d?.ayahs||d?.ayat||d?.data?.verses||d?.data?.ayahs||[]);
if(Array.isArray(arr)&&arr.length)break}
catch(e){
}
}
if(Array.isArray(arr)&&arr.length){
result.verses=result.verses.map((v,i)=>{
const source=arr[i];
if(!source)return v;
const sv=source?.tafsir||source?.tafsirs||source?.interpretation?source:(source?.data||source);
return {
...v,tafsir:{
...(v?.tafsir||{
}
),...(sv?.tafsir||{
}
),...(sv?.tafsirs||{
}
),kemenag:{
...(v?.tafsir?.kemenag||{
}
),...(sv?.tafsir?.kemenag||{
}
),...(sv?.tafsirs?.kemenag||{
}
),...(sv?.tafsir_kemenag||sv?.tafsirKemenag||{
}
)}
,quraish:sv?.tafsir?.quraish||sv?.tafsir?.quraish_shihab||sv?.tafsirs?.quraish||sv?.tafsir_quraish||sv?.tafsir_quraish_shihab||v?.tafsir?.quraish||v?.tafsir?.quraish_shihab,jalalayn:sv?.tafsir?.jalalayn||sv?.tafsirs?.jalalayn||sv?.tafsir_jalalayn||v?.tafsir?.jalalayn}
}
}
);
}
}
catch(e){
}
return result;
}
function initJuzOptions(){
juzSelect.innerHTML='';
for(let n=1;
n<=30;
n++){
const o=document.createElement('option');
o.value=n;
o.textContent=`Juz ${
String(n).padStart(2,'0')}
`;
juzSelect.appendChild(o)}
juzSelect.value='30'}
async function loadList(){
const [a,b]=juzRanges[Number(juzSelect.value)]||[78,114];
surahSelect.innerHTML='';
for(let n=a;
n<=b;
n++){
const o=document.createElement('option');
o.value=n;
o.textContent=`${
n}
. ${
surahNames[n]||'Surah '+n}
`;
surahSelect.appendChild(o)}
surahSelect.value=String(a);
await loadSurah();
}
async function enrichWithGading(n,result){
try{
const gj=await fetchJSON(`https://api.quran.gading.dev/surah/${
n}
`);
const gd=unwrap(gj),ga=gd?.verses||gd?.ayahs||[];
if(ga.length&&result.verses?.length){
result.verses=result.verses.map((v,i)=>{
const g=ga[i]||{
}
;
const latin=latinOf(v);
const merged={
...v}
;
if(!latin||latin.startsWith('Transliterasi belum tersedia')){
merged.transliteration=merged.transliteration||g?.text?.transliteration||g?.transliteration;
merged.text=merged.text||{
}
;
if(!merged.text.transliteration&&g?.text?.transliteration)merged.text.transliteration=g.text.transliteration;
}
if(!transOf(v)||transOf(v).startsWith('Terjemahan belum tersedia')){
merged.translation=merged.translation||g?.translation||g?.text?.translation;
}
return merged}
)}
}
catch(e){
}
return result;
}
async function getSurahData(n){
if(quranCache[n]&&completeSurahData(n,quranCache[n]))return quranCache[n];
delete quranCache[n];
const problems=[];
try{
const j=await fetchJSON(`https://api.myquran.com/v3/quran/${
n}
`);
const d=unwrap(j);
let arr=Array.isArray(d)?d:(d?.ayahs||d?.verses||d?.ayat||d?.data);
if(Array.isArray(arr)&&arr.length===ayahCounts[n-1]){
const meta=d?.surah||d?.meta||{
}
;
let result=await enrichWithGading(n,{
number:n,name:meta.name_latin||meta.name||surahNames[n],verses:arr,source:'MyQuran v3 + transliterasi cadangan'}
);
result=normalizeSurahData(n,result);
if(result){
quranCache[n]=result;
cacheText(n,result);
return result}
}
else problems.push(`MyQuran mengirim ${
Array.isArray(arr)?arr.length:0}
/${
ayahCounts[n-1]}
ayat`);
}
catch(e){
problems.push('MyQuran: '+e.message)}
try{
const j=await fetchJSON(`https://quran-api-id.vercel.app/surahs/${
n}
`);
let d=unwrap(j);
let arr=d?.ayahs||d?.verses||d?.ayat||[];
if(!Array.isArray(arr)||arr.length!==ayahCounts[n-1]){
const k=await fetchJSON(`https://quran-api-id.vercel.app/surahs/${
n}
/ayahs`);
d=unwrap(k);
arr=Array.isArray(d)?d:(d?.ayahs||d?.verses||d?.data||[]);
}
if(Array.isArray(arr)&&arr.length===ayahCounts[n-1]){
let result=await enrichWithGading(n,{
number:n,name:d?.name_latin||d?.name||surahNames[n],verses:arr,source:'Quran API ID + transliterasi cadangan'}
);
result=normalizeSurahData(n,result);
if(result){
quranCache[n]=result;
cacheText(n,result);
return result}
}
else problems.push(`Quran API ID mengirim ${
Array.isArray(arr)?arr.length:0}
/${
ayahCounts[n-1]}
ayat`);
}
catch(e){
problems.push('Quran API ID: '+e.message)}
try{
const j=await fetchJSON(`https://api.quran.gading.dev/surah/${
n}
`);
const d=unwrap(j);
const arr=d?.verses||d?.ayahs||[];
if(Array.isArray(arr)&&arr.length===ayahCounts[n-1]){
const result=normalizeSurahData(n,{
number:n,name:d?.name?.transliteration?.id||surahNames[n],verses:arr,source:'Quran Gading'}
);
if(result){
quranCache[n]=result;
cacheText(n,result);
return result}
}
else problems.push(`Quran Gading mengirim ${
Array.isArray(arr)?arr.length:0}
/${
ayahCounts[n-1]}
ayat`);
}
catch(e){
problems.push('Gading: '+e.message)}
try{
const j=await fetchJSON(`https://api.alquran.cloud/v1/surah/${
n}
`);
const d=j?.data;
const arr=d?.ayahs||[];
if(Array.isArray(arr)&&arr.length===ayahCounts[n-1]){
let result=await enrichWithGading(n,{
number:n,name:d?.englishName||surahNames[n],verses:arr,source:'Al Quran Cloud + transliterasi cadangan'}
);
result=normalizeSurahData(n,result);
if(result){
quranCache[n]=result;
cacheText(n,result);
return result}
}
else problems.push(`Al Quran Cloud mengirim ${
Array.isArray(arr)?arr.length:0}
/${
ayahCounts[n-1]}
ayat`);
}
catch(e){
problems.push('Al Quran Cloud: '+e.message)}
const cached=readCache(n);
if(completeSurahData(n,cached)){
const result=normalizeSurahData(n,cached);
quranCache[n]=result;
return result}
throw new Error(`Data surah belum lengkap. Seharusnya ${
ayahCounts[n-1]}
ayat. Sumber yang dicoba: ${
problems.join(' | ')}
. Periksa koneksi internet lalu tekan Muat surah lagi.`);
}
function cacheText(n,obj){
try{
if(!completeSurahData(n,obj))return;
const all=JSON.parse(localStorage.getItem(CACHE)||'{
}
');
all[n]=obj;
localStorage.setItem(CACHE,JSON.stringify(all))}
catch(e){
}
}
function readCache(n){
try{
const all=JSON.parse(localStorage.getItem(CACHE)||'{
}
');
const item=all[n];
return completeSurahData(n,item)?normalizeSurahData(n,item):null}
catch{
return null}
}
function limitVersesToJuz(surahNum,fullData){
const bounds=juzAyahBounds[Number(juzSelect.value)];
if(!bounds)return fullData;
const [[startSurah,startAyah],[endSurah,endAyah]]=bounds;
if(surahNum<startSurah||surahNum>endSurah)return {
...fullData,verses:[]}
;
const verses=(fullData.verses||[]).filter((v,i)=>{
const a=Number(getNum(v,i));
if(surahNum===startSurah&&a<startAyah)return false;
if(surahNum===endSurah&&a>endAyah)return false;
return true}
);
return {
...fullData,verses}
}
async function loadSurah(){
const n=Number(surahSelect.value);
stopPlayback();
player.removeAttribute('src');
player.load();
statusBox.textContent='Memuat ayat…';
versesBox.innerHTML='';
currentSurah=null;
try{
let full;
try{
full=await getSurahData(n)}
catch(e){
full=readCache(n);
if(!full)throw e;
statusBox.textContent='Memakai data teks tersimpan di browser. '+e.message}
if(!completeSurahData(n,full))throw new Error(`Data API tidak lengkap (${
full?.verses?.length||0}
/${
ayahCounts[n-1]}
ayat). Coba muat ulang saat internet stabil.`);
full=await enrichWithTafsir(n,full);
const data=limitVersesToJuz(n,normalizeSurahData(n,full));
currentSurah={
...data,number:n}
;
const arr=data.verses||[];
if(!arr.length)throw new Error('Tidak ada ayat pada surah ini untuk juz yang dipilih.');
statusBox.textContent=`${
data.name||surahNames[n]}
· ${
arr.length}
ayat dalam Juz ${
juzSelect.value}
· sumber: ${
data.source||'cache lokal'}
`;
arr.forEach((v,i)=>renderVerse(n,v,i,data.name||surahNames[n]));
activeVerseIndex=0;
showActiveVerse();
updateProgress();
renderCurrentText();
}
catch(e){
statusBox.textContent='Ayat belum berhasil dimuat. '+e.message}
}
function renderVerse(s,v,i,title){
const num=getNum(v,i),st=readStore(),mem=st[key(s,num)]||{
}
;
const previousCard=versesBox.querySelectorAll('.ayah')[i-1];
const previousEnd=previousCard?.querySelector('.end')?.value||'';
const defaultStart=i===0?1:previousEnd;
const card=document.createElement('article');
card.className='ayah'+(hideText?' hiddenText':'');
card.id=`ayah-${
s}
-${
num}
`;
card.dataset.ayah=num;
card.innerHTML=`<div class="ayahhead"><span class="num"></span><label class="check"><input type="checkbox" ${
mem.done?'checked':''}
> Sudah hafal</label></div><div class="arabic" lang="ar" dir="rtl"></div><div class="translit"></div><button class="versePlay">▶ Play media</button><div class="translation"></div><div class="timegrid" ${
$('useOffline').checked?'':'hidden'}
><div><label>Mulai (detik)</label><input class="start" type="number" min="0" step="0.1" placeholder="mis. 1" value="${
mem.start??defaultStart}
"></div><div><label>Akhir (detik)</label><input class="end" type="number" min="0" step="0.1" placeholder="detik akhir ayat" value="${
mem.end??''}
"></div></div><div class="tiny timingNote" ${
$('useOffline').checked?'':'hidden'}
>Isi waktu akhir ayat ini. Waktu mulai ayat berikutnya otomatis mengikuti waktu akhir ayat sebelumnya.</div>`;
card.querySelector('.num').textContent=`${
title}
· Ayat ${
num}
`;
card.querySelector('.arabic').textContent=arabOf(v);
card.querySelector('.translit').textContent='Latin: '+latinOf(v);
card.querySelector('.translation').dataset.translation=transOf(v);
card.querySelector('.translation').textContent='Arti: '+transOf(v);
card.querySelector('input[type=checkbox]').addEventListener('change',()=>{
const x=readStore(),k=key(s,num);
x[k]={
...(x[k]||{
}
),done:card.querySelector('input[type=checkbox]').checked}
;
writeStore(x);
updateProgress()}
);
card.querySelector('.versePlay').addEventListener('click',()=>{
const cards=[...versesBox.querySelectorAll('.ayah')];
activeVerseIndex=cards.indexOf(card);
stopPlayback();
showActiveVerse();
loadABSettings();
prepareActiveAudio()}
);
const startInput=card.querySelector('.start'),endInput=card.querySelector('.end');
function saveTimeInputs(){
const x=readStore(),k=key(s,num),a=startInput.value===''?null:Number(startInput.value),b=endInput.value===''?null:Number(endInput.value);
x[k]={
...(x[k]||{
}
),start:a,end:b}
;
writeStore(x)}
startInput.addEventListener('change',saveTimeInputs);
endInput.addEventListener('change',()=>{
saveTimeInputs();
const cards=[...versesBox.querySelectorAll('.ayah')],idx=cards.indexOf(card),next=cards[idx+1];
if(next){
const nextStart=next.querySelector('.start');
if(nextStart){
nextStart.value=endInput.value;
const nx=readStore(),nextKey=key(s,next.dataset.ayah);
nx[nextKey]={
...(nx[nextKey]||{
}
),start:endInput.value===''?null:Number(endInput.value)}
;
writeStore(nx)}
}
}
);
versesBox.appendChild(card)
}
function renderCurrentText(){
if(!currentSurah)return;
const mode=$('textMode').value;
const arr=currentSurah.verses||[];
arr.forEach((v,i)=>{
const num=getNum(v,i),card=$(`ayah-${
currentSurah.number}
-${
num}
`);
if(!card)return;
const el=card.querySelector('.translation');
let txt=mode==='translation'?transOf(v):tafsirOf(v,mode);
el.textContent=(mode==='translation'?'Arti: ':'Tafsir: ')+(txt|| (mode==='translation'?'Terjemahan belum tersedia dari sumber ini.':'Data tafsir ini belum tersedia dari API. Coba muat ulang atau pilih terjemahan Indonesia.'));
el.style.whiteSpace='pre-wrap';
}
);
}
function showActiveVerse(){
const cards=[...versesBox.querySelectorAll('.ayah')];
if(!cards.length){
$('verseCounter').textContent='Ayat — / —';
$('prevVerse').disabled=true;
$('nextVerse').disabled=true;
return}
activeVerseIndex=Math.max(0,Math.min(activeVerseIndex,cards.length-1));
cards.forEach((c,i)=>c.classList.toggle('active',i===activeVerseIndex));
$('verseCounter').textContent=`${
activeVerseIndex+1}
/ ${
cards.length}
`;
$('prevVerse').disabled=activeVerseIndex===0;
$('nextVerse').disabled=activeVerseIndex===cards.length-1;
$('prevVerse').style.opacity=activeVerseIndex===0?'.5':'1';
$('nextVerse').style.opacity=activeVerseIndex===cards.length-1?'.5':'1';
loadABSettings()}
function updateProgress(){
if(!currentSurah)return;
const n=Number(surahSelect.value),arr=currentSurah.verses||[],st=readStore();
let done=0;
arr.forEach((v,i)=>{
if(st[key(n,getNum(v,i))]?.done)done++}
);
$('progressBar').style.width=(arr.length?done/arr.length*100:0)+'%';
$('progressText').textContent=`Hafal ${
done}
dari ${
arr.length}
ayat (${
arr.length?Math.round(done/arr.length*100):0}
%). Progres tersimpan di browser perangkat ini.`}
function repeatSetting(){
return $('repeat').value==='infinity'?Infinity:Number($('repeat').value)||5}
function activeVerseKey(){
const card=versesBox.querySelectorAll('.ayah')[activeVerseIndex];
return card?key(Number(surahSelect.value),Number(card.dataset.ayah)):null}
function activeMem(){
const k=activeVerseKey();
return k?(readStore()[k]||{
}
):{
}
}
function saveActiveMem(patch){
const k=activeVerseKey();
if(!k)return;
const x=readStore();
x[k]={
...(x[k]||{
}
),...patch}
;
writeStore(x)}
function fmtTime(t){
if(!Number.isFinite(t)||t<0)t=0;
const m=Math.floor(t/60),sec=Math.floor(t%60);
return String(m).padStart(2,'0')+':'+String(sec).padStart(2,'0')}
function loadABSettings(){
if(!$('repeat'))return;
const mem=activeMem();
$('repeat').value=mem.loopRepeat??'5';
$('currentTime').textContent=fmtTime(player.currentTime||0);
$('durationTime').textContent=fmtTime(player.duration);
$('abStatus').textContent=`Titik A: ${
Number.isFinite(mem.loopA)?fmtTime(mem.loopA):'belum ditentukan'}
· Titik B: ${
Number.isFinite(mem.loopB)?fmtTime(mem.loopB):'belum ditentukan'}
`;
const valid=Number.isFinite(mem.loopA)&&Number.isFinite(mem.loopB)&&mem.loopA>=0&&mem.loopB>mem.loopA;
$('playLoop').disabled=!valid||!player.src;
$('setA').disabled=!player.src||!Number.isFinite(player.duration);
$('setB').disabled=!player.src||!Number.isFinite(player.duration);
$('seekBar').disabled=!player.src||!Number.isFinite(player.duration);
}
function stopPlayback(){
playToken++;
isPlayingSequence=false;
clearInterval(loopTimer);
loopTimer=null;
player.pause();
$('stopLoop').disabled=true;
if($('playLoop'))$('playLoop').textContent='▶ Play loop'}
function setSeekFromTime(){
if(!Number.isFinite(player.duration)||player.duration<=0)return;
$('seekBar').value=String(Math.round((player.currentTime/player.duration)*1000));
$('currentTime').textContent=fmtTime(player.currentTime);
$('durationTime').textContent=fmtTime(player.duration)}
async function prepareActiveAudio(){
if(!currentSurah)return;
stopPlayback();
const card=versesBox.querySelectorAll('.ayah')[activeVerseIndex];
if(!card)return;
const mem=activeMem();
$('abStatus').textContent='Menyiapkan audio…';
try{
if($('useOnline').checked){
const i=activeVerseIndex,v=(currentSurah.verses||[])[i],num=getNum(v,i),sn=Number(surahSelect.value),edition=$('qari').value,global=v?.number?.inQuran||v?.number_in_quran||v?.global_number||globalAyah(sn,Number(num));
const urls=[`https://api.alquran.cloud/v1/ayah/${
global}
/${
edition}
`,v?.audio_url,v?.audio?.primary].filter(Boolean);
let loaded=false;
for(const url of urls){
try{
let src=url;
if(url.includes('api.alquran.cloud')){
const j=await fetchJSON(url);
src=j?.data?.audio;
if(!src)continue}
player.src=src;
player.load();
await new Promise((resolve,reject)=>{
if(player.readyState>=1&&Number.isFinite(player.duration))return resolve();
const ok=()=>{
cleanup();
resolve()}
,bad=()=>{
cleanup();
reject(new Error('Audio tidak bisa dimuat'))}
,cleanup=()=>{
player.removeEventListener('loadedmetadata',ok);
player.removeEventListener('error',bad)}
;
player.addEventListener('loadedmetadata',ok,{
once:true}
);
player.addEventListener('error',bad,{
once:true}
);
setTimeout(()=>{
cleanup();
reject(new Error('Waktu tunggu audio habis'))}
,12000)}
);
loaded=true;
break}
catch(e){
continue}
}
if(!loaded)throw new Error('Audio online tidak tersedia untuk qari ini.')}
else{
if(!localAudioUrl)throw new Error('Unggah file audio offline terlebih dahulu.');
player.src=localAudioUrl;
player.load();
await new Promise((resolve,reject)=>{
if(player.readyState>=1&&Number.isFinite(player.duration))return resolve();
const ok=()=>{
cleanup();
resolve()}
,bad=()=>{
cleanup();
reject(new Error('File audio tidak bisa dibaca'))}
,cleanup=()=>{
player.removeEventListener('loadedmetadata',ok);
player.removeEventListener('error',bad)}
;
player.addEventListener('loadedmetadata',ok,{
once:true}
);
player.addEventListener('error',bad,{
once:true}
);
setTimeout(()=>{
cleanup();
reject(new Error('Waktu tunggu file audio habis'))}
,12000)}
)}
const a=Number.isFinite(mem.loopA)?mem.loopA:(! $('useOnline').checked&&Number.isFinite(mem.start)?mem.start:null),b=Number.isFinite(mem.loopB)?mem.loopB:(! $('useOnline').checked&&Number.isFinite(mem.end)?mem.end:null);
if(a!==null&&a<player.duration)player.currentTime=a;
else player.currentTime=0;
setSeekFromTime();
$('abStatus').textContent=`Audio siap (${
fmtTime(player.duration)}
). Geser garis waktu, tandai A dan B, lalu tekan Play loop.`;
loadABSettings();
}
catch(e){
$('abStatus').textContent=e.message;
statusBox.textContent=e.message}
}
function markAB(which){
if(!player.src||!Number.isFinite(player.duration)){
statusBox.textContent='Tekan “Siapkan audio ayat aktif” dulu.';
return}
const t=player.currentTime;
const mem=activeMem(),card=versesBox.querySelectorAll('.ayah')[activeVerseIndex];
if(which==='A'){
saveActiveMem({
loopA:t,loopB:null,start:t,end:null}
);
if(card){
card.querySelector('.start').value=String(t.toFixed(1));
card.querySelector('.end').value=''}
$('abStatus').textContent=`Titik A disimpan di ${
fmtTime(t)}
. Geser ke titik akhir lalu tandai B.`}
else{
const a=mem.loopA;
if(!Number.isFinite(a)){
$('abStatus').textContent='Tentukan titik A terlebih dahulu.';
return}
if(t<=a){
$('abStatus').textContent='Titik B harus lebih akhir daripada titik A.';
return}
saveActiveMem({
loopB:t,end:t}
);
if(card)card.querySelector('.end').value=String(t.toFixed(1))}
loadABSettings()}
function playLoop(){
const mem=activeMem();
if(!player.src||!Number.isFinite(mem.loopA)||!Number.isFinite(mem.loopB)||mem.loopB<=mem.loopA){
$('abStatus').textContent='Siapkan audio dan tentukan titik A serta B terlebih dahulu.';
return}
stopPlayback();
const token=playToken;
loopStart=mem.loopA;
loopEnd=mem.loopB;
loopLeft=repeatSetting();
saveActiveMem({
loopRepeat:$('repeat').value}
);
isPlayingSequence=true;
player.currentTime=loopStart;
player.play().then(()=>{
statusBox.textContent='Looping ayat aktif…';
$('stopLoop').disabled=false;
$('playLoop').textContent='▶ Memutar…';
clearInterval(loopTimer);
loopTimer=setInterval(()=>{
if(token!==playToken||!isPlayingSequence)return;
if(player.currentTime>=loopEnd){
if(loopLeft===Infinity){
player.currentTime=loopStart;
player.play().catch(()=>{
}
)}
else{
loopLeft--;
if(loopLeft>0){
player.currentTime=loopStart;
player.play().catch(()=>{
}
)}
else{
player.pause();
player.currentTime=loopEnd;
clearInterval(loopTimer);
loopTimer=null;
isPlayingSequence=false;
$('stopLoop').disabled=true;
$('playLoop').textContent='▶ Play loop';
$('abStatus').textContent=`Selesai ${
$('repeat').value}
pengulangan. Audio berhenti di titik B (${
fmtTime(loopEnd)}
).`;
setSeekFromTime()}
}
}
}
,40)}
).catch(()=>{
isPlayingSequence=false;
$('abStatus').textContent='Audio gagal diputar. Coba siapkan audio lagi.'}
)}
$('prepareAudio').addEventListener('click',prepareActiveAudio);
$('setA').addEventListener('click',()=>markAB('A'));
$('setB').addEventListener('click',()=>markAB('B'));
$('playLoop').addEventListener('click',playLoop);
$('stopLoop').addEventListener('click',stopPlayback);
$('resetAB').addEventListener('click',()=>{
stopPlayback();
saveActiveMem({
loopA:null,loopB:null,start:null,end:null}
);
const card=versesBox.querySelectorAll('.ayah')[activeVerseIndex];
if(card){
card.querySelector('.start').value='';
card.querySelector('.end').value=''}
$('abStatus').textContent='Titik A dan B direset untuk ayat ini.';
loadABSettings()}
);
$('seekBar').addEventListener('input',()=>{
if(!Number.isFinite(player.duration))return;
player.currentTime=(Number($('seekBar').value)/1000)*player.duration;
setSeekFromTime()}
);
player.addEventListener('timeupdate',setSeekFromTime);
player.addEventListener('loadedmetadata',()=>{
setSeekFromTime();
loadABSettings()}
);
$('repeat').addEventListener('change',()=>saveActiveMem({
loopRepeat:$('repeat').value}
));
function setAudioMode(){
const online=$('useOnline').checked,offline=$('useOffline').checked;
$('onlineOptions').hidden=!online;
$('offlineOptions').hidden=!offline;
document.querySelectorAll('.timegrid,.timingNote').forEach(el=>el.hidden=!offline);
document.querySelectorAll('.versePlay').forEach(el=>el.textContent='Pilih ayat & siapkan audio');
if(online&&$('useOffline').checked){
$('useOffline').checked=false;
$('offlineOptions').hidden=true;
document.querySelectorAll('.timegrid,.timingNote').forEach(el=>el.hidden=true)}
if(offline&&$('useOnline').checked){
$('useOnline').checked=false;
$('onlineOptions').hidden=true}
if(!online&&!offline){
$('useOffline').checked=true;
$('offlineOptions').hidden=false;
document.querySelectorAll('.timegrid,.timingNote').forEach(el=>el.hidden=false)}
stopPlayback();
player.removeAttribute('src');
player.load();
setSeekFromTime();
loadABSettings()}
$('prevVerse').addEventListener('click',()=>{
stopPlayback();
if(activeVerseIndex>0){
activeVerseIndex--;
showActiveVerse();
player.removeAttribute('src');
player.load();
loadABSettings()}
}
);
$('nextVerse').addEventListener('click',()=>{
stopPlayback();
const cards=versesBox.querySelectorAll('.ayah');
if(activeVerseIndex<cards.length-1){
activeVerseIndex++;
showActiveVerse();
player.removeAttribute('src');
player.load();
loadABSettings()}
}
);
$('juz').addEventListener('change',()=>{
stopPlayback();
loadList()}
);
$('load').onclick=()=>{
stopPlayback();
loadSurah()}
;
$('surah').addEventListener('change',()=>{
stopPlayback();
loadSurah()}
);
$('textMode').addEventListener('change',renderCurrentText);
$('showText').onclick=()=>{
hideText=!hideText;
document.querySelectorAll('.ayah').forEach(x=>x.classList.toggle('hiddenText',hideText));
$('showText').textContent=hideText?'Tampilkan teks':'Sembunyikan teks'}
;
$('useOnline').addEventListener('change',()=>{
if($('useOnline').checked)$('useOffline').checked=false;
setAudioMode()}
);
$('useOffline').addEventListener('change',()=>{
if($('useOffline').checked)$('useOnline').checked=false;
setAudioMode(false)}
);
$('qari').addEventListener('change',()=>{
if($('useOnline').checked)prepareActiveAudio()}
);
$('audioFile').addEventListener('change',e=>{
const f=e.target.files?.[0];
if(!f)return;
if(localAudioUrl)URL.revokeObjectURL(localAudioUrl);
localAudioUrl=URL.createObjectURL(f);
currentSource='local';
statusBox.textContent='Audio lokal siap: '+f.name;
saveAudioBlob(f,f.name)}
);
// Simpan audio lokal di IndexedDB jika didukung browser.
const DB='forumDawaiAudioDB';
function openDB(){
return new Promise((resolve,reject)=>{
if(!('indexedDB'in window))return reject(new Error('IndexedDB tidak didukung'));
const req=indexedDB.open(DB,1);
req.onupgradeneeded=()=>req.result.createObjectStore('audio');
req.onsuccess=()=>resolve(req.result);
req.onerror=()=>reject(req.error)}
)}
async function saveAudioBlob(blob,name){
try{
const db=await openDB();
await new Promise((res,rej)=>{
const tx=db.transaction('audio','readwrite');
tx.objectStore('audio').put({
blob,name}
,'current');
tx.oncomplete=res;
tx.onerror=()=>rej(tx.error)}
);
db.close()}
catch(e){
}
}
async function restoreAudio(){
try{
const db=await openDB();
const item=await new Promise((res,rej)=>{
const r=db.transaction('audio').objectStore('audio').get('current');
r.onsuccess=()=>res(r.result);
r.onerror=()=>rej(r.error)}
);
db.close();
if(item?.blob){
localAudioUrl=URL.createObjectURL(item.blob);
statusBox.textContent='Audio lokal tersimpan tersedia: '+item.name}
}
catch(e){
}
}
let localAudioUrl=null;
initJuzOptions();
$('useOffline').checked=true;
$('useOnline').checked=false;
setAudioMode(false);
loadList().then(()=>{
loadABSettings();
restoreAudio()}
);